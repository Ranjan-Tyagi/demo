package com.cg;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class google {
	
	public static void main(String[] args) throws InterruptedException
	{
    	System.setProperty("webdriver.chrome.driver", "C:\\BDD\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
    	WebDriver d;
    	d=new ChromeDriver();
        d.get("http://www.google.com");
        d.manage().window().maximize();
      // WebElement w= d.findElement(By.cssSelector("input.gLFyf[name='q']"));
     //  w.sendKeys("");
      //d.findElement(By.linkText("Business")).click();
     //d.findElement(By.xpath("//*[@id='submitBtn']")).click();
        Thread.sleep(3000);
        WebElement e= d.findElement(By.name("q"));
        e.sendKeys("Fighter Aircraft");
        Thread.sleep(3000);
        WebDriverWait wait = new WebDriverWait(d, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("btnK")));
       d.findElement(By.name("btnK")).click();
       d.findElement(By.partialLinkText("Images")).click();
       //JavaScriptExecuter a=new JavaScriptExecuterDriver();
       Thread.sleep(3000);
    
       for(int x=0;x<=10;x++)
       {
    	   JavascriptExecutor jse = (JavascriptExecutor)d;
           jse.executeScript("window.scrollBy(0,2500)", "");
           Thread.sleep(2000);
           x++;
       }
       
	
	}

}
